package xchel.co.personalchat.Extra;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;

import xchel.co.personalchat.Adapters.ClientAdapter;
import xchel.co.personalchat.Entities.FireBase.Client;
import xchel.co.personalchat.Entities.Logica.LClient;


public class Save {

    public static final String adminName = "Xchel Alonso";

    public static Client client;
    public static RecyclerView recyclerViewMain;
    public static ClientAdapter clientAdapter;
    public static FirebaseRecyclerAdapter adapterChat;
    public static Context context;

    public static final String clientReference = "Cliente";
    public static final String chatReference = "Messages";
    public static final String keyAdmin = "4R3WU1WaClNyo6HJxzKbkrMoBUY2";
    public static String keyClient;

    public static LClient lClient;
}
